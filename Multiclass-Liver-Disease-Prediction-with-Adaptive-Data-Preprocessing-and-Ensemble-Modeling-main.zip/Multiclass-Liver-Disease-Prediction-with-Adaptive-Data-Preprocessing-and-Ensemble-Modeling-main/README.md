This repository has been established to aid readers in comprehending the liver disease prediction research detailed in the paper. 
Essential files are provided within the repository, and all analyses have been conducted in the paper by examining the codes from various sections. 
Graphs and plots have not been included, as they can be adjusted according to the preferences of the readers. 
Therefore, it is left to the discretion of the readers to reproduce them as needed.Python and main essential libraries used for this project:

python version:3.12.0

Numpy Version:1.26.1

Scikit-learn version:1.3.1

If you like the content, don't forget to give a star
